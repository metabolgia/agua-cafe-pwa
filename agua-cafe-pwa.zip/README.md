# Agua Café PWA

App interactiva para calcular recetas de agua remineralizada para café según método, tueste y perfil sensorial.

Diseñada para ser instalada como app en Android desde el navegador (PWA).
